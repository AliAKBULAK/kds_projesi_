document.addEventListener('DOMContentLoaded', () => {
  // State variables
  let staffData = [];
  let charts = {}; // Store Chart.js instances

  // DOM Elements
  const staffTableBody = document.getElementById('staffTableBody');
  const calculateBtn = document.getElementById('calculateBtn');
  const saveBtn = document.getElementById('saveScenarioBtn');
  const navDashboard = document.getElementById('nav-dashboard');
  const navHistory = document.getElementById('nav-history');
  const dashboardSection = document.getElementById('dashboard-section');
  const historySection = document.getElementById('history-section');

  // Inputs
  const inputs = {
    scenarioName: document.getElementById('scenarioName'),
    inflation: document.getElementById('inflationRate'),
    margin: document.getElementById('profitMargin'),
    rooms: document.getElementById('totalRooms'),
    occupancy: document.getElementById('occupancyRate'),
    fixedCost: document.getElementById('fixedCost'),
    variableCost: document.getElementById('variableCost')
  };

  // Displays
  const displays = {
    price: document.getElementById('suggestedPriceDisplay'),
    cost: document.getElementById('totalCostDisplay'),
    profit: document.getElementById('netProfitDisplay')
  };

  // --- INITIALIZATION ---
  fetchStaffConfig();
  setupNavigation();

  // --- NAVIGATION ---
  function setupNavigation() {
    navDashboard.addEventListener('click', (e) => {
      e.preventDefault();
      switchTab('dashboard');
    });
    navHistory.addEventListener('click', (e) => {
      e.preventDefault();
      switchTab('history');
      loadHistoryData();
    });
  }

  function switchTab(tab) {
    if (tab === 'dashboard') {
      dashboardSection.style.display = 'block';
      historySection.style.display = 'none';
      navDashboard.classList.add('active');
      navHistory.classList.remove('active');
    } else {
      dashboardSection.style.display = 'none';
      historySection.style.display = 'block';
      navDashboard.classList.remove('active');
      navHistory.classList.add('active');
    }
  }

  // --- DASHBOARD LOGIC ---

  async function fetchStaffConfig() {
    try {
      const res = await fetch('http://localhost:3000/api/staff-config');
      staffData = await res.json();
      renderStaffTable();
    } catch (err) {
      console.error('Error fetching staff config:', err);
      staffTableBody.innerHTML = '<tr><td colspan="4" class="text-danger">Veri yüklenemedi. Server açık mı?</td></tr>';
    }
  }

  function renderStaffTable() {
    staffTableBody.innerHTML = '';
    staffData.forEach((role, index) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${role.role_name}</td>
                <td>${formatCurrency(role.current_salary)}</td>
                <td><input type="number" class="form-control form-control-sm staff-count" data-index="${index}" value="${role.default_count}" min="0"></td>
                <td><input type="number" class="form-control form-control-sm staff-raise" data-index="${index}" value="0" min="0" max="100"></td>
            `;
      staffTableBody.appendChild(row);
    });
  }

  calculateBtn.addEventListener('click', () => {
    calculateScenario();
  });

  saveBtn.addEventListener('click', () => {
    saveSimulation();
  });

  let lastCalculation = null;

  function calculateScenario() {
    // 1. Gather Inputs
    const inflation = parseFloat(inputs.inflation.value) / 100;
    const margin = parseFloat(inputs.margin.value) / 100;
    const totalRooms = parseInt(inputs.rooms.value);
    const occupancy = parseFloat(inputs.occupancy.value) / 100;
    const monthlyFixed = parseFloat(inputs.fixedCost.value);
    const perRoomVar = parseFloat(inputs.variableCost.value);

    // 2. Calculate Staff Cost
    let totalStaffCost = 0;
    const staffDetails = [];

    const countInputs = document.querySelectorAll('.staff-count');
    const raiseInputs = document.querySelectorAll('.staff-raise');

    staffData.forEach((role, i) => {
      const count = parseInt(countInputs[i].value);
      const raise = parseFloat(raiseInputs[i].value) / 100;
      const salary = parseFloat(role.current_salary);

      const roleMonthlyCost = salary * (1 + raise) * count;
      totalStaffCost += roleMonthlyCost;

      staffDetails.push({
        role_name: role.role_name,
        count: count,
        raise_percentage: raise * 100 // store as percentage
      });
    });

    // 3. Calculate Operations Cost
    // Variable cost = Per Room * (Rooms * Occupancy) * 30 days
    const occupiedRooms = totalRooms * occupancy;
    const monthlyVariable = perRoomVar * occupiedRooms * 30;
    const totalOpsCost = monthlyFixed + monthlyVariable;

    // 4. Totals & Inflation
    const baseTotalCost = totalStaffCost + totalOpsCost;
    const inflatedTotalCost = baseTotalCost * (1 + inflation);

    // 5. Unit Cost & Price
    // Unit cost per occupied room night
    const totalOccupiedRoomNights = occupiedRooms * 30;

    let unitCost = 0;
    if (totalOccupiedRoomNights > 0) {
      unitCost = inflatedTotalCost / totalOccupiedRoomNights;
    }

    const suggestedPrice = unitCost * (1 + margin);

    // 6. Projections
    const monthlyRevenue = suggestedPrice * totalOccupiedRoomNights;
    const monthlyProfit = monthlyRevenue - inflatedTotalCost;

    // Update UI
    displays.price.innerText = formatCurrency(suggestedPrice);
    displays.cost.innerText = formatCurrency(inflatedTotalCost);
    displays.profit.innerText = formatCurrency(monthlyProfit);

    if (monthlyProfit >= 0) {
      displays.profit.className = 'fw-bold text-success';
    } else {
      displays.profit.className = 'fw-bold text-danger';
    }

    saveBtn.disabled = false;

    lastCalculation = {
      scenario_name: inputs.scenarioName.value,
      inflation_rate: inflation * 100,
      profit_margin: margin * 100,
      final_suggested_price: suggestedPrice,
      staff_details: staffDetails
    };

    // Update Charts
    updateCharts(totalStaffCost, monthlyFixed, monthlyVariable, monthlyRevenue, inflatedTotalCost, monthlyProfit);
  }

  function updateCharts(staff, fixed, variable, income, expense, profit) {
    // Pie Chart: Cost Breakdown
    const ctxPie = document.getElementById('costBreakdownChart').getContext('2d');
    if (charts.pie) charts.pie.destroy();
    charts.pie = new Chart(ctxPie, {
      type: 'pie',
      data: {
        labels: ['Personel', 'Sabit Gider', 'Değişken Gider'],
        datasets: [{
          data: [staff, fixed, variable],
          backgroundColor: ['#003366', '#FFC107', '#28A745']
        }]
      },
      options: { responsive: true, plugins: { title: { display: true, text: 'Maliyet Dağılımı' } } }
    });

    // Doughnut: Income vs Expense
    const ctxDoughnut = document.getElementById('incomeExpenseDoughnut').getContext('2d');
    if (charts.doughnut) charts.doughnut.destroy();
    charts.doughnut = new Chart(ctxDoughnut, {
      type: 'doughnut',
      data: {
        labels: ['Gider', 'Kar'],
        datasets: [{
          data: [expense, profit > 0 ? profit : 0],
          backgroundColor: ['#DC3545', '#003366']
        }]
      },
      options: { responsive: true }
    });

    // Bar: Forecast
    const ctxBar = document.getElementById('profitForecastBar').getContext('2d');
    if (charts.bar) charts.bar.destroy();
    charts.bar = new Chart(ctxBar, {
      type: 'bar',
      data: {
        labels: ['Tahmini Rapor'],
        datasets: [
          { label: 'Gelir', data: [income], backgroundColor: '#003366' },
          { label: 'Gider', data: [expense], backgroundColor: '#DC3545' },
          { label: 'Net Kar', data: [profit], backgroundColor: '#28A745' }
        ]
      },
      options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
  }

  async function saveSimulation() {
    if (!lastCalculation) return;
    const name = inputs.scenarioName.value || 'Adsız Senaryo ' + new Date().toLocaleTimeString();
    lastCalculation.scenario_name = name;

    try {
      const res = await fetch('http://localhost:3000/api/save-simulation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lastCalculation)
      });

      if (res.ok) {
        alert('Senaryo başarıyla kaydedildi!');
        inputs.scenarioName.value = ''; // Reset name
        saveBtn.disabled = true;
      } else {
        alert('Hata oluştu.');
      }
    } catch (err) {
      console.error(err);
      alert('Sunucu hatası.');
    }
  }

  // --- HISTORY LOGIC ---

  async function loadHistoryData() {
    try {
      const res = await fetch('http://localhost:3000/api/history');
      const data = await res.json();
      renderHistoryTable(data);
      renderHistoryChart(data);
    } catch (err) {
      console.error(err);
    }
  }

  function renderHistoryTable(data) {
    const tbody = document.getElementById('historyTable').querySelector('tbody');
    tbody.innerHTML = '';
    data.forEach(item => {
      const profit = parseFloat(item.profit);
      const rowClass = profit >= 0 ? 'table-success' : 'table-danger';
      const status = profit >= 0 ? 'KAR' : 'ZARAR';

      const tr = document.createElement('tr');
      tr.innerHTML = `
                <td>${item.period}</td>
                <td>${formatCurrency(item.income)}</td>
                <td>${formatCurrency(item.expense)}</td>
                <td class="${profit >= 0 ? 'text-success fw-bold' : 'text-danger fw-bold'}">${formatCurrency(profit)}</td>
                <td><span class="badge ${profit >= 0 ? 'bg-success' : 'bg-danger'}">${status}</span></td>
            `;
      tbody.appendChild(tr);
    });
  }

  function renderHistoryChart(data) {
    const ctx = document.getElementById('historyChart').getContext('2d');
    if (charts.history) charts.history.destroy();

    charts.history = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.map(d => d.period),
        datasets: [
          {
            label: 'Gelir',
            data: data.map(d => d.income),
            backgroundColor: '#003366'
          },
          {
            label: 'Gider',
            data: data.map(d => d.expense),
            backgroundColor: '#DC3545'
          }
        ]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true } }
      }
    });
  }

  // Utility
  function formatCurrency(amount) {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  }
});