
// Chart.js Configuration & Theme
const CHART_COLORS = {
    primary: '#003366',
    primaryLight: '#335c85',
    danger: '#ef4444',
    success: '#10b981',
    warning: '#f59e0b',
    grey: '#cbd5e1'
};

let chartInstances = {};

function initCharts() {
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.color = '#64748b';
}

function renderDashboardCharts(data) {
    // 1. Gelir vs Gider (Doughnut)
    const incomeCtx = document.getElementById('chart-income-expense').getContext('2d');

    // Varolan grafiği temizle
    if (chartInstances.income) chartInstances.income.destroy();

    chartInstances.income = new Chart(incomeCtx, {
        type: 'doughnut',
        data: {
            labels: ['Toplam Gelir', 'Toplam Gider'],
            datasets: [{
                data: [data.summary.totalIncome, data.summary.totalExpense],
                backgroundColor: ['#60a5fa', '#f59e0b'], // Light Blue, Orange
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            rotation: -90, // Start from top? No, User wants Income Left. 
            // If we assume a standard clock:
            // 0 is Top.
            // Income (First) triggers first.
            // If we want Income to be on the Left side (9 o'clock centric),
            // We should start drawing from Bottom (180 deg) so it goes 6 -> 9 -> 12.
            rotation: 180,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });

    // 2. Aylık Gelir/Gider Trendi (Bar)
    const trendCtx = document.getElementById('chart-monthly-trend').getContext('2d');
    if (chartInstances.trend) chartInstances.trend.destroy();

    const labels = data.monthlyData.map(d => d.month);
    const incomeData = data.monthlyData.map(d => d.total_income);
    const expenseData = data.monthlyData.map(d =>
        parseFloat(d.personnel_expense) + parseFloat(d.kitchen_expense) +
        parseFloat(d.fixed_expense) + parseFloat(d.other_expense)
    );

    chartInstances.trend = new Chart(trendCtx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Gelir',
                    data: incomeData,
                    backgroundColor: CHART_COLORS.primary,
                    borderRadius: 4
                },
                {
                    label: 'Gider',
                    data: expenseData,
                    backgroundColor: CHART_COLORS.danger,
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { display: true } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderSimulationCharts(simData) {
    // 1. Maliyet Dağılımı (Pie)
    const breakdownCtx = document.getElementById('chart-sim-breakdown').getContext('2d');

    if (chartInstances.breakdown) {
        // Grafiği güncelle (Re-render yerine Update)
        chartInstances.breakdown.data.datasets[0].data = [
            simData.breakdown.personnel,
            simData.breakdown.kitchen,
            simData.breakdown.fixed,
            simData.breakdown.other
        ];
        chartInstances.breakdown.update();
    } else {
        // İlk kez oluştur
        chartInstances.breakdown = new Chart(breakdownCtx, {
            type: 'pie',
            data: {
                labels: ['Personel', 'Mutfak', 'Sabit', 'Diğer'],
                datasets: [{
                    data: [
                        simData.breakdown.personnel,
                        simData.breakdown.kitchen,
                        simData.breakdown.fixed,
                        simData.breakdown.other
                    ],
                    backgroundColor: ['#003366', '#336699', '#6699cc', '#99ccff'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'right' } }
            }
        });
    }

    // 2. Aylık Tahmini Kar (Bar)
    const profitCtx = document.getElementById('chart-sim-profit').getContext('2d');
    const monthlyProfits = Array.from({ length: 12 }, (_, i) => {
        let factor = (i > 4 && i < 9) ? 1.5 : 0.8;
        return (simData.pricing.suggestedPrice * 30 * 100 * (simData.occupancy / 100) * factor) - (simData.unitCost * 30 * 100 * (simData.occupancy / 100));
    });

    if (chartInstances.profit) {
        chartInstances.profit.data.datasets[0].data = monthlyProfits;
        chartInstances.profit.data.datasets[0].backgroundColor = monthlyProfits.map(val => val < 0 ? CHART_COLORS.danger : CHART_COLORS.success);
        chartInstances.profit.update();
    } else {
        chartInstances.profit = new Chart(profitCtx, {
            type: 'bar',
            data: {
                labels: ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'],
                datasets: [{
                    label: 'Tahmini Kar',
                    data: monthlyProfits,
                    backgroundColor: monthlyProfits.map(val => val < 0 ? CHART_COLORS.danger : CHART_COLORS.success)
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // 3. Duyarlılık Analizi (Tornado Chart)
    const sensitivityCtx = document.getElementById('chart-sensitivity').getContext('2d');

    if (chartInstances.sensitivity) {
        chartInstances.sensitivity.data.datasets[0].data = [
            simData.sensitivity.inflationImpact,
            simData.sensitivity.raiseImpact,
            simData.sensitivity.occupancyImpact
        ];
        chartInstances.sensitivity.update();
    } else {
        chartInstances.sensitivity = new Chart(sensitivityCtx, {
            type: 'bar',
            data: {
                labels: ['Enflasyon (+%10)', 'Personel Zammı (+%10)', 'Doluluk (-%10)'],
                datasets: [{
                    label: 'Kâr Kaybı (TL)',
                    data: [
                        simData.sensitivity.inflationImpact,
                        simData.sensitivity.raiseImpact,
                        simData.sensitivity.occupancyImpact
                    ],
                    backgroundColor: [CHART_COLORS.danger, CHART_COLORS.warning, CHART_COLORS.primaryLight],
                    borderRadius: 4
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                scales: { x: { title: { display: true, text: 'Kâr Düşüşü (TL)' } } },
                plugins: { legend: { display: false } }
            }
        });
    }
}


function renderExpenseTrendChart(labels, fixedData, variableData) {
    const ctx = document.getElementById('chart-sim-expense-trend').getContext('2d');

    if (chartInstances.expenseTrend) {
        chartInstances.expenseTrend.data.datasets[0].data = fixedData;
        chartInstances.expenseTrend.data.datasets[1].data = variableData;
        chartInstances.expenseTrend.update();
    } else {
        chartInstances.expenseTrend = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Sabit Gider (Personel+Sabit)',
                        data: fixedData,
                        backgroundColor: '#334155', // Dark Grey
                        stack: 'Stack 0'
                    },
                    {
                        label: 'Değişken Gider (Mutfak+Diğer)',
                        data: variableData,
                        backgroundColor: '#f59e0b', // Orange
                        stack: 'Stack 0'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        stacked: true,
                    },
                    y: {
                        stacked: true,
                        beginAtZero: true
                    }
                },
                plugins: {
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    }
                }
            }
        });
    }
}

function renderHistoryCharts(data) {
    // 1. Occupancy Trend (Line Chart)
    const occCtx = document.getElementById('chart-history-occupancy').getContext('2d');
    const labels = data.monthlyData.map(d => d.month);
    const occupancyData = data.monthlyData.map(d => parseFloat(d.occupancy_rate));

    // Constant Target Line (Example 70%) or Dynamic if we had it
    const targetData = new Array(12).fill(70);

    if (chartInstances.historyOcc) {
        chartInstances.historyOcc.data.labels = labels;
        chartInstances.historyOcc.data.datasets[0].data = occupancyData;
        chartInstances.historyOcc.update();
    } else {
        chartInstances.historyOcc = new Chart(occCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Gerçekleşen Doluluk (%)',
                        data: occupancyData,
                        borderColor: CHART_COLORS.primary,
                        backgroundColor: CHART_COLORS.primary,
                        tension: 0.3
                    },
                    {
                        label: 'Genel Hedef (%70)',
                        data: targetData,
                        borderColor: CHART_COLORS.danger,
                        borderDash: [5, 5],
                        borderWidth: 2,
                        pointRadius: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true, max: 100 } }
            }
        });
    }

    // 2. Finance Trend (Multi-Line: Income vs Expense)
    const finCtx = document.getElementById('chart-history-finance').getContext('2d');
    const incomeData = data.monthlyData.map(d => parseFloat(d.total_income));
    const expenseData = data.monthlyData.map(d =>
        parseFloat(d.personnel_expense) + parseFloat(d.kitchen_expense) +
        parseFloat(d.fixed_expense) + parseFloat(d.other_expense)
    );

    if (chartInstances.historyFin) {
        chartInstances.historyFin.data.labels = labels;
        chartInstances.historyFin.data.datasets[0].data = incomeData;
        chartInstances.historyFin.data.datasets[1].data = expenseData;
        chartInstances.historyFin.update();
    } else {
        chartInstances.historyFin = new Chart(finCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Toplam Gelir (TL)',
                        data: incomeData,
                        borderColor: CHART_COLORS.success,
                        backgroundColor: CHART_COLORS.success,
                        tension: 0.3,
                        fill: false
                    },
                    {
                        label: 'Toplam Gider (TL)',
                        data: expenseData,
                        borderColor: CHART_COLORS.danger,
                        backgroundColor: CHART_COLORS.danger,
                        tension: 0.3,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true } }
            }
        });
    }
}
