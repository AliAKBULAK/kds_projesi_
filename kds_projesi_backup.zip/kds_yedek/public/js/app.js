// Main App Logic

const API_URL = 'http://localhost:3000/api';

// State
let dashboardData = {};

document.addEventListener('DOMContentLoaded', () => {
    initCharts(); // Chart.js init
    setupNavigation();
    loadDashboardData(2024); // Default year
    loadSavedScenarios(); // NEW: Load Sidebar List

    // Year Filter Listener
    document.getElementById('year-select').addEventListener('change', (e) => {
        loadDashboardData(e.target.value);
    });

    // History Year Filter Listener
    const historySelect = document.getElementById('history-year-select');
    if (historySelect) {
        historySelect.addEventListener('change', (e) => {
            loadHistoryData(e.target.value);
        });
        // Load initial history data (2024)
        loadHistoryData('2024');
    }
    // Logout
    document.getElementById('btn-logout').addEventListener('click', () => {
        if (confirm('Çıkış yapılsın mı?')) {
            localStorage.removeItem('kds_token');
            localStorage.removeItem('kds_user');
            window.location.href = 'login.html';
        }
    });
});

function setupNavigation() {
    const links = document.querySelectorAll('.menu-item');
    const sections = document.querySelectorAll('.page-section');

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('data-target');

            // Set Active Menu
            links.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            // Set Active Section
            sections.forEach(sec => sec.classList.remove('active'));
            document.getElementById(targetId).classList.add('active');

            // Update Header Title
            document.getElementById('page-title').innerText = link.innerText.trim();

        });
    });
}



async function loadDashboardData(year) {
    try {
        const res = await fetch(`${API_URL}/data/${year}`);
        const data = await res.json();

        dashboardData[year] = data;

        updateKPIs(data.summary);
        renderDashboardCharts(data);

        // If loading 2024, init simulation automatically
        if (year == 2024) {
            initSimulation(data);
        }

    } catch (err) {
        console.error("Veri yüklenemedi:", err);
    }
}

function updateKPIs(summary) {
    document.getElementById('kpi-income').innerText = formatCurrency(summary.totalIncome);
    document.getElementById('kpi-occupancy').innerText = '%' + summary.avgOccupancy.toFixed(1);
    document.getElementById('kpi-customers').innerText = summary.totalCustomers.toLocaleString('tr-TR');
    document.getElementById('kpi-price').innerText = formatCurrency(summary.avgPrice);
}

// Reuse helper
function formatCurrency(val) {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(val);
}

async function loadHistoryData(year) {
    // Reuse existing API
    try {
        const res = await fetch(`${API_URL}/data/${year}`);
        const data = await res.json();
        renderHistoryCharts(data);
    } catch (err) {
        console.error("Geçmiş veri yüklenemedi:", err);
    }
}

async function loadSavedScenarios() {
    const list = document.getElementById('saved-scenarios-list');
    try {
        const res = await fetch(`${API_URL}/simulation/list`);
        const scenarios = await res.json();

        if (scenarios.length === 0) {
            list.innerHTML = '<li style="color: #94a3b8; font-size: 13px;">Kayıtlı senaryo yok.</li>';
            return;
        }

        list.innerHTML = '';
        scenarios.forEach(s => {
            const li = document.createElement('li');
            li.style.marginBottom = '8px';
            li.innerHTML = `
                <a href="#" class="scenario-link" 
                   data-inflation="${s.enflasyon_orani}" 
                   data-raise="${s.zam_orani}" 
                   data-occupancy="${s.hedef_doluluk}" 
                   data-margin="${s.onerilen_fiyat}" 
                   style="color: #cbd5e1; text-decoration: none; font-size: 13px; display: flex; align-items: center;">
                   <!-- Custom Icon -->
                   <img src="img/scenario_icon.jpg" alt="Icon" style="width: 16px; height: 16px; margin-right: 8px; border-radius: 3px; opacity: 0.8;">
                   ${s.senaryo_adi}
                </a>
            `;

            // Click Handler to Load Scenario
            li.querySelector('a').addEventListener('click', (e) => {
                e.preventDefault();
                loadScenarioToSimulation(s);
            });

            list.appendChild(li);
        });

    } catch (err) {
        console.error('Senaryolar çekilemedi:', err);
        list.innerHTML = '<li style="color: #ef4444; font-size: 13px;">Liste hatası.</li>';
    }
}

function loadScenarioToSimulation(saved) {
    // 1. Switch to Simulation Tab
    document.querySelector('[data-target="simulation"]').click();

    // 2. Populate Inputs (Waiting for DOM update)
    setTimeout(() => {
        const inputs = {
            inflation: document.getElementById('sim-inflation'),
            raise: document.getElementById('sim-raise'),
            occupancy: document.getElementById('sim-occupancy'),
        };

        if (inputs.inflation) {
            inputs.inflation.value = saved.enflasyon_orani;
            document.getElementById('val-inflation').innerText = saved.enflasyon_orani + '%';
        }
        if (inputs.raise) {
            inputs.raise.value = saved.zam_orani;
            document.getElementById('val-raise').innerText = saved.zam_orani + '%';
        }
        if (inputs.occupancy) {
            inputs.occupancy.value = saved.hedef_doluluk;
            document.getElementById('val-occupancy').innerText = saved.hedef_doluluk + '%';
        }

        // Trigger Simulation Run if function exists
        if (typeof runSimulation === 'function') {
            // Trigger input events to update state
            if (inputs.inflation) inputs.inflation.dispatchEvent(new Event('input'));
            if (inputs.raise) inputs.raise.dispatchEvent(new Event('input'));
            if (inputs.occupancy) inputs.occupancy.dispatchEvent(new Event('input'));
        }

        console.log(`Loaded scenario: ${saved.senaryo_adi}`);

    }, 200);
}
