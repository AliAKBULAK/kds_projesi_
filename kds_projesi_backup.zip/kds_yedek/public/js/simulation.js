// Simulation Logic

// 3 Default Scenarios
const scenarios = {
    'A': { id: 'A', name: 'Kötümser', inflation: 60, raise: 60, occupancy: 50, margin: 10 },
    'B': { id: 'B', name: 'Normal', inflation: 40, raise: 50, occupancy: 70, margin: 25 },
    'C': { id: 'C', name: 'İyimser', inflation: 20, raise: 30, occupancy: 90, margin: 40 }
};

let currentScenarioId = 'B'; // Default
let referenceData = null;
let currentRates = { USD: 0, EUR: 0 }; // Store live rates

// UI Elements
const inputs = {
    inflation: document.getElementById('sim-inflation'),
    raise: document.getElementById('sim-raise'),
    occupancy: document.getElementById('sim-occupancy'),
    margin: document.getElementById('sim-margin')
};

const labels = {
    inflation: document.getElementById('val-inflation'),
    raise: document.getElementById('val-raise'),
    occupancy: document.getElementById('val-occupancy'),
    margin: document.getElementById('val-margin')
};



async function initSimulation(data2024) {
    // 1. Fetch Live Currency Rates
    await fetchCurrencyRates();

    if (!data2024) return;

    // Calculate Reference Averages from 2024 Data
    const totalPers = data2024.monthlyData.reduce((sum, d) => sum + parseFloat(d.personnel_expense), 0);
    const totalKitchen = data2024.monthlyData.reduce((sum, d) => sum + parseFloat(d.kitchen_expense), 0);
    const totalFixed = data2024.monthlyData.reduce((sum, d) => sum + parseFloat(d.fixed_expense), 0);
    const totalOther = data2024.monthlyData.reduce((sum, d) => sum + parseFloat(d.other_expense), 0);

    referenceData = {
        personnel: totalPers,
        kitchen: totalKitchen,
        fixed: totalFixed,
        other: totalOther
    };

    // Attach Listeners
    Object.keys(inputs).forEach(key => {
        inputs[key].addEventListener('input', (e) => {
            // Update Current Scenario State
            scenarios[currentScenarioId][key] = parseInt(e.target.value);
            // Update Label
            labels[key].innerText = scenarios[currentScenarioId][key] + '%';
            // Run Calc
            runSimulation();
        });
    });

    // Initialize UI with Default Scenario
    loadScenarioToUI('B');
}

function switchScenario(scenarioId) {
    currentScenarioId = scenarioId;

    // Update Tabs UI
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.innerText.includes(`Senaryo ${scenarioId}`)) {
            btn.classList.add('active');
        }
    });

    loadScenarioToUI(scenarioId);
}

function loadScenarioToUI(id) {
    const s = scenarios[id];

    // Set Slider Values
    inputs.inflation.value = s.inflation;
    inputs.raise.value = s.raise;
    inputs.occupancy.value = s.occupancy;
    inputs.margin.value = s.margin;

    // Set Labels
    labels.inflation.innerText = s.inflation + '%';
    labels.raise.innerText = s.raise + '%';
    labels.occupancy.innerText = s.occupancy + '%';
    labels.margin.innerText = s.margin + '%';

    runSimulation();
}

function runSimulation() {
    if (!referenceData) return;

    const s = scenarios[currentScenarioId];
    const ref = referenceData;

    // 1. Calculate Future Expenses
    const newPersonnel = ref.personnel * (1 + s.raise / 100);
    const inflationMultiplier = (1 + s.inflation / 100);
    const newKitchen = ref.kitchen * inflationMultiplier;
    const newFixed = ref.fixed * inflationMultiplier;
    const newOther = ref.other * inflationMultiplier;

    const totalProjectedCost = newPersonnel + newKitchen + newFixed + newOther;

    // 2. Unit Cost Calculation
    const totalRooms = 100;
    const totalRoomNights = totalRooms * 365 * (s.occupancy / 100);
    const unitCost = totalProjectedCost / totalRoomNights;

    // 3. Suggested Price
    const suggestedPrice = unitCost * (1 + s.margin / 100);
    const totalIncome = suggestedPrice * totalRoomNights; // Revenue
    const totalProfit = totalIncome - totalProjectedCost;

    // Update UI
    // Update UI
    document.getElementById('sim-suggested-price').innerHTML = `
        ${formatCurrency(suggestedPrice)} 
        <span style="display:block; font-size:14px; color:#2c3e50; margin-top:4px;">
            ($${(suggestedPrice / (currentRates.USD || 1)).toFixed(2)})
        </span>
    `;
    document.getElementById('sim-unit-cost').innerText = formatCurrency(unitCost) + ' / gece';

    // Update Charts
    // 4. SENSITIVITY ANALYSIS (Duyarlılık Analizi)
    // "What if bad things happen?" (+10% Inflation, +10% Raise, -10% Occupancy)

    // Base Case Profit
    const baseProfit = totalProfit;

    // Case 1: Inflation + 10 points
    const infBad = s.inflation + 10;
    const multInfBad = (1 + infBad / 100);
    const costInfBad = newPersonnel + (ref.kitchen * multInfBad) + (ref.fixed * multInfBad) + (ref.other * multInfBad);
    const profitInfBad = totalIncome - costInfBad;
    const impactInflation = baseProfit - profitInfBad;

    // Case 2: Raise + 10 points
    const raiseBad = s.raise + 10;
    const costRaiseBad = (ref.personnel * (1 + raiseBad / 100)) + newKitchen + newFixed + newOther;
    const profitRaiseBad = totalIncome - costRaiseBad;
    const impactRaise = baseProfit - profitRaiseBad;

    // Case 3: Occupancy - 10 points (Revenue Loss)
    const occBad = s.occupancy - 10;
    const roomsBad = totalRooms * 365 * (occBad / 100);
    const incomeBad = suggestedPrice * roomsBad;
    // Note: Variable costs (Kitchen) would also decrease with less occupancy, but keeping simple for impact demo
    // Let's adjust kitchen cost for accuracy
    const kitchenUnitCost = newKitchen / totalRoomNights; // Current unit cost
    const kitchenBad = kitchenUnitCost * roomsBad;
    const costOccBad = newPersonnel + kitchenBad + newFixed + newOther;
    const profitOccBad = incomeBad - costOccBad;
    const impactOccupancy = baseProfit - profitOccBad;

    // Update Charts
    renderSimulationCharts({
        breakdown: {
            personnel: newPersonnel,
            kitchen: newKitchen,
            fixed: newFixed,
            other: newOther
        },
        pricing: {
            suggestedPrice: suggestedPrice,
        },
        occupancy: s.occupancy,
        unitCost: unitCost,
        sensitivity: {
            inflationImpact: impactInflation,
            raiseImpact: impactRaise,
            occupancyImpact: impactOccupancy
        }
    });

    // 5. EXPENSE TREND ANALYSIS (Sabit vs Değişken Dağılımı)
    // Sezonsallık Simülasyonu (Basit model: Yazın yüksek doluluk, kışın düşük)
    const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

    // Fixed Costs are constant per month
    const monthlyFixed = (newPersonnel + newFixed) / 12;

    // Variable Costs depend on seasonality factor
    // Yaz sezonu (Jun-Sep) katsayısı yüksek, Kış düşük
    const seasonality = [0.6, 0.7, 0.8, 1.0, 1.2, 1.5, 1.8, 1.8, 1.4, 1.1, 0.8, 0.7]; // Toplam ortalama ~1.0 olmalı ama basit tutuyoruz

    // Normalize seasonality so average is 1.0 (to match total variable cost)
    const avgSeason = seasonality.reduce((a, b) => a + b, 0) / 12;
    const normalizedSeasonality = seasonality.map(v => v / avgSeason);

    const totalVariableYearly = newKitchen + newOther;
    const avgVariableMonthly = totalVariableYearly / 12;

    const monthlyFixedData = months.map(() => monthlyFixed);
    const monthlyVariableData = months.map((m, i) => avgVariableMonthly * normalizedSeasonality[i]);

    renderExpenseTrendChart(months, monthlyFixedData, monthlyVariableData);

    // RUN EXPERT SYSTEM (AI)
    generateAIInsights(s, unitCost, suggestedPrice, totalProfit);
}

// 🧠 KDS EXPERT SYSTEM LOGIC
function generateAIInsights(scenario, unitCost, price, profit) {
    const aiText = document.getElementById('ai-text');
    let messages = [];

    // Rule 1: Profitability Check
    if (profit < 0) {
        messages.push(`⚠️ <strong>KRİTİK UYARI:</strong> Bu senaryoda otel zarar ediyor! Fiyatı artırmalı veya giderleri kısmalısınız.`);
    } else if (scenario.margin < 15) {
        messages.push(`⚠️ <strong>Düşük Kârlılık:</strong> Kar marjınız (%${scenario.margin}) sektör ortalamasının altında. Riskli bir operasyon.`);
    } else {
        messages.push(`✅ <strong>Kârlı Operasyon:</strong> Mevcut parametreler ile işletme sağlıklı görünüyor.`);
    }

    // Rule 2: Occupancy vs Price Analysis
    if (scenario.occupancy < 50 && price > 3000) {
        messages.push(`💡 <strong>Strateji Önerisi:</strong> Doluluk çok düşük (%${scenario.occupancy}). Fiyatı düşürüp (Kampanya) sürümden kazanmayı deneyin.`);
    } else if (scenario.occupancy > 90 && scenario.margin < 30) {
        messages.push(`📈 <strong>Fırsat:</strong> Doluluk oranınız çok yüksek (%${scenario.occupancy}). Talebi yönetmek için fiyatları artırma (Yield Management) fırsatınız var.`);
    }

    // Rule 3: Cost Analysis
    if (scenario.inflation > 50) {
        messages.push(`🔥 <strong>Yüksek Enflasyon Riski:</strong> %${scenario.inflation} enflasyon senaryosunda sabit giderlerinizi kontrol altına almanız hayati önem taşır.`);
    }

    // Output Result
    // Pick top 2 most important messages
    aiText.innerHTML = messages.join('<br><br>');
}


function formatCurrency(val) {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(val);
}

// 💾 SAVE SCENARIO FUNCTION
async function saveCurrentScenario() {
    const s = scenarios[currentScenarioId];

    // We need to recalculate or grab the Suggested Price. 
    // Since it's calculated inside runSimulation, let's grab it from the DOM or recalculate.
    // Better to recalculate to be safe.

    // Recalculate Logic (Simplified copy from runSimulation)
    const ref = referenceData;
    const newPersonnel = ref.personnel * (1 + s.raise / 100);
    const inflationMultiplier = (1 + s.inflation / 100);
    const newKitchen = ref.kitchen * inflationMultiplier;
    const newFixed = ref.fixed * inflationMultiplier;
    const newOther = ref.other * inflationMultiplier;
    const totalProjectedCost = newPersonnel + newKitchen + newFixed + newOther;
    const totalRooms = 100;
    const totalRoomNights = totalRooms * 365 * (s.occupancy / 100);
    const unitCost = totalProjectedCost / totalRoomNights;
    const suggestedPrice = unitCost * (1 + s.margin / 100);

    const payload = {
        scenario_name: `${s.name} Senaryo (Otomatik)`,
        inflation_rate: s.inflation,
        raise_rate: s.raise,
        target_occupancy: s.occupancy,
        suggested_price: parseFloat(suggestedPrice.toFixed(2))
    };

    try {
        const response = await fetch('/api/simulation/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (response.ok) {
            alert('✅ Senaryo başarıyla veritabanına kaydedildi!');
            // Auto reload the sidebar list (Global function from app.js)
            if (typeof loadSavedScenarios === 'function') {
                loadSavedScenarios();
            }
        } else {
            alert('❌ Kayıt sırasında hata oluştu.');
        }
    } catch (error) {
        console.error('Save error:', error);
        alert('❌ Sunucuya bağlanılamadı.');
    }
}


async function fetchCurrencyRates() {
    try {
        const res = await fetch('/api/currency');
        const rates = await res.json();

        if (rates.USD) {
            currentRates = rates;
            console.log('Güncel Kurlar:', currentRates);
        }
    } catch (err) {
        console.error('Kur çekilemedi:', err);
    }
}
