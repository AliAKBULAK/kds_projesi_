const SimulationModel = require('../models/SimulationModel');

exports.saveSimulation = async (data) => {
    return await SimulationModel.create(data);
};

exports.getAllScenarios = async () => {
    return await SimulationModel.findAll();
};
