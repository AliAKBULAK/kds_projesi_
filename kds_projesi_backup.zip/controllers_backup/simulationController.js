const SimulationModel = require('../models/SimulationModel');

exports.saveSimulation = async (req, res) => {
    try {
        await SimulationModel.create(req.body);
        res.json({ message: 'Simülasyon başarıyla kaydedildi!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Kaydedilemedi' });
    }
};
