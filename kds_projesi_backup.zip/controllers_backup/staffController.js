const StaffModel = require('../models/StaffModel');

exports.getAllStaff = async (req, res) => {
    try {
        const rows = await StaffModel.findAll();
        res.json(rows);
    } catch (error) {
        console.error('Personel API Hatası:', error);
        res.status(500).json({ error: 'Personel listesi çekilemedi' });
    }
};
